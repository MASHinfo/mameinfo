@ECHO OFF
CLS
REM XP32
REM set path=d:\msys64\mingw32\bin;d:\msys64\usr\bin;%PATH%
REM set MINGW32=d:/msys64/mingw32

REM X64
REM set path=d:\msys64\mingw64\bin;d:\msys64\usr\bin;%PATH%
REM set MINGW32=d:/msys64/mingw64

d:
cd \msys64\tmp\mame-master

REM make -j5
REM make -j5 SUBTARGET=arcade
REM make -j5 SUBTARGET=mess
REM make -j5 SUBTARGET=tinymame SOURCES=src/mame/namco/rallyx.cpp REGENIE=1
REM make -j5 OSD=winui SUBTARGET=arcade   NOTE: This version needs the extra winui files from https://github.com/Robbbert/mameui

IF ERRORLEVEL 2 GOTO ERROR

ECHO.
ECHO READY!
REM
REM COPY /Y d:\msys64\tmp\mame-master\mamearcade.exe D:\MAME\mame.exe >NUL
REM
GOTO END
:ERROR
ECHO.
ECHO ERROR!
:END
set path=%PATH%
PAUSE > NUL