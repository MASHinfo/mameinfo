@ECHO OFF
REM WORKING DIRECTORY
set DIR=D:\msys64\tmp\mame-master\build



mode con:cols=50 lines=10
CLS
ECHO.
ECHO Delete 0 byte files...
ECHO.
ECHO.

d:
cd %DIR%
for /r "%~1." %%A in (*.*) do if %%~zA == 0 del "%%~fA"

ECHO.
ECHO READY!


REM
REM
REM For only command line not batch use
REM
REM for /r %F in (*.*) do @if %~zF==0 del "%F"
REM

