cd /
sed -i -e "\$acd /tmp/mame-master" "/home/$USER/.bashrc"

echo " "
echo " "
echo -e "\e[33mDownload and install MINGW64 packages...\e[0m"
echo " "
echo " "
pacman -S --noconfirm mingw-w64-ucrt-x86_64-gcc
pacman -S --noconfirm mingw-w64-ucrt-x86_64-python
pacman -S --noconfirm mingw-w64-ucrt-x86_64-lld
pacman -S --noconfirm mingw-w64-ucrt-x86_64-llvm-tools
pacman -S --noconfirm mingw-w64-ucrt-x86_64-llvm
pacman -S --noconfirm mingw-w64-ucrt-x86_64-make
pacman -S --noconfirm mingw-w64-ucrt-x86_64-7zip
cp /ucrt64/bin/mingw32-make.exe /ucrt64/bin/make.exe

cd /tmp
echo " "
echo " "
echo " "
echo " "
echo -e "\e[33mDownload and extract newest MAME source...\e[0m"
echo " "
echo " "
wget --no-check-certificate https://codeload.github.com/mamedev/mame/zip/master -O mame.zip && 7z x mame.zip


cd /tmp/mame-master

# Patch new MAME source
sed -bi "s/# SSE2 = 1/SSE2 = 1/g" makefile

cd /tmp
echo " "
echo " "
echo " "
echo -e "\e[33mAuto-generate arcade.flt and mess.flt files for MAME...\e[0m"
echo " "
7z x XPackage.zip
cmd //c arcade+mess-flt.bat

echo " "
echo " "
echo " "
echo -e "\e[33mYou can go offline!... >>>>>>  Restart ucrt64.exe launcher !!!\e[0m"
echo " "
echo " "
rm libkernel32.a psapi.h mame.zip XPackage.zip EDITBIN.EXE LINK.EXE MSPDB60.DLL init.sh
