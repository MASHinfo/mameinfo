cd /tmp
echo " "
echo "GIT for Windows 10 (64bit) MAME version..."
echo " "
echo "Remove old MAME source..."
rm -r mame-master
echo " "
echo " "
echo -e "\e[33mDownload and extract newest MAME source...\e[0m"
echo " "
echo " "
wget --no-check-certificate https://codeload.github.com/mamedev/mame/zip/master -O mame.zip && 7z x mame.zip


cd /tmp/mame-master

# Patch new MAME source
sed -bi "s/# SSE2 = 1/SSE2 = 1/g" makefile

cd /tmp
echo " "
echo " "
echo " "
echo -e "\e[33mAuto-generate arcade.flt and mess.flt files for MAME...\e[0m"
echo " "
cmd //c arcade+mess-flt.bat

echo " "
echo " "
echo " "
echo -e "\e[33mYou can go offline!\e[0m"
echo " "
echo " "
rm mame.zip
cd mame-master
