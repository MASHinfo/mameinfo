cd /
sed -i -e "\$acd /tmp/mame-master" "/home/$USER/.bashrc"

echo " "
echo " "
echo -e "\e[33mDownload and install Clang64 packages...\e[0m"
echo " "
echo " "
pacman -S --noconfirm mingw-w64-clang-x86_64-clang
pacman -S --noconfirm mingw-w64-clang-x86_64-gcc-compat
pacman -S --needed --noconfirm mingw-w64-clang-x86_64-lld
pacman -S --needed --noconfirm mingw-w64-clang-x86_64-llvm-tools
pacman -S --noconfirm mingw-w64-clang-x86_64-llvm
pacman -S --needed --noconfirm mingw-w64-clang-x86_64-libc++
pacman -S --needed --noconfirm mingw-w64-clang-x86_64-python
pacman -S --noconfirm mingw-w64-clang-x86_64-make
pacman -S --noconfirm mingw-w64-clang-x86_64-7zip
cp /clang64/bin/mingw32-make.exe /clang64/bin/make.exe

cd /tmp
echo " "
echo " "
echo " "
echo " "
echo -e "\e[33mDownload and extract newest MAME source...\e[0m"
echo " "
echo " "
wget --no-check-certificate https://codeload.github.com/mamedev/mame/zip/master -O mame.zip && 7z x mame.zip


cd /tmp/mame-master

# Patch new MAME source
sed -bi "s/# SSE2 = 1/SSE2 = 1/g" makefile

# MAME.exe error: libc++abi: terminating due to uncaught exception of type std::runtime_error: collate_byname<char>::collate_byname failed to construct for .UTF-8
sed -bi "s/std::locale const syslocale(\".UTF-8\")/std::locale const syslocale(\"\")/g" src/osd/windows/winmain.cpp


cd /tmp
echo " "
echo " "
echo " "
echo -e "\e[33mAuto-generate arcade.flt and mess.flt files for MAME...\e[0m"
echo " "
7z x XPackage.zip
cmd //c arcade+mess-flt.bat

echo " "
echo " "
echo " "
echo -e "\e[33mYou can go offline!... >>>>>>  Restart clang64.exe launcher !!!\e[0m"
echo " "
echo " "
rm libkernel32.a psapi.h mame.zip XPackage.zip EDITBIN.EXE LINK.EXE MSPDB60.DLL init.sh
