cd /
sed -i -e "\$acd /tmp/mame-master" "/home/$USER/.bashrc"

echo " "
echo " "
echo -e "\e[33mDownload and install Mingw32 packages...\e[0m"
echo " "
echo " "
pacman -S --noconfirm mingw-w64-i686-gcc
pacman -S --noconfirm mingw-w64-i686-python
pacman -S --noconfirm mingw-w64-i686-make
pacman -U --noconfirm https://repo.msys2.org/mingw/mingw32/mingw-w64-i686-7zip-26.01-1-any.pkg.tar.zst   

cp /mingw32/bin/mingw32-make.exe /mingw32/bin/make.exe

cd /tmp
echo " "
echo " "
echo " "
echo " "
echo -e "\e[33mDownload and extract newest MAME source...\e[0m"
echo " "
echo " "
wget --no-check-certificate https://codeload.github.com/mamedev/mame/zip/master -O mame.zip && 7z x mame.zip


cd /tmp/mame-master

# Patch new MAME source
sed -bi "s/# SSE2 = 1/SSE2 = 1/g" makefile

# Compiled 'mamearcadeui.exe' crashed at start
sed -bi "s/\t\t\x22osd_\x22 ../--\t\t\x22osd_\x22 ../g; s/\t\t\x22qtdbg_\x22 ../--\t\t\x22qtdbg_\x22 ../g; s/\t\t\x22optional\x22,/\t\t\x22osd_\x22 .. _OPTIONS[\x22osd\x22], \x22qtdbg_\x22 .. _OPTIONS[\x22osd\x22], \x22optional\x22,/g" scripts/src/main.lua

# 'TaskDialog' missing in comctl32.dll (Windows XP)
sed -bi "s/\x09\x09\x09if \x28SUCCEEDED\x28SHCreateItem/\x2f\x2f\x09\x09\x09if (SUCCEEDED(SHCreateItem/g" src/osd/modules/debugger/win/consolewininfo.cpp
sed -bi "s/\t\tint pressed;/#ifdef UNUSED_FUNCTION\n\t\tint pressed;/g" src/osd/modules/debugger/win/consolewininfo.cpp
sed -bi "s/\t\t\t\t&pressed);/\t\t\t\t\&pressed);\n#endif/g" src/osd/modules/debugger/win/consolewininfo.cpp

# 'DPI' missing in Windows XP
sed -bi "s/top + MulDiv(100, xdpi/top + MulDiv(100, ydpi/g" src/osd/modules/debugger/debugwin.cpp
sed -bi "s/GetDpiForMonitor(/\/\/GetDpiForMonitor(/g" src/osd/modules/debugger/debugwin.cpp
sed -bi "s/AdjustWindowRectExForDpi(&target, GetWindowLong(window, GWL_STYLE), GetMenu(window) ? TRUE : FALSE, GetWindowLong(window, GWL_EXSTYLE), GetDpiForWindow(window))/AdjustWindowRectEx(\&target, GetWindowLong(window, GWL_STYLE), GetMenu(window) ? TRUE : FALSE, GetWindowLong(window, GWL_EXSTYLE))/g" src/osd/modules/debugger/debugwin.cpp
sed -bi "s/AdjustWindowRectExForDpi(&bounds, DEBUG_WINDOW_STYLE, FALSE, DEBUG_WINDOW_STYLE_EX, metrics().dpi())/AdjustWindowRectEx(\&bounds, DEBUG_WINDOW_STYLE, FALSE, DEBUG_WINDOW_STYLE_EX)/g" src/osd/modules/debugger/win/consolewininfo.cpp
sed -bi "s/GetDpiForWindow(m_wnd)/96/g" src/osd/modules/debugger/win/debugwininfo.cpp
sed -bi "s/AdjustWindowRectExForDpi(\(.*\), *metrics().dpi())/AdjustWindowRectEx(\1)/g" src/osd/modules/debugger/win/debugwininfo.cpp
sed -bi "s/AdjustWindowRectExForDpi(&bounds, DEBUG_WINDOW_STYLE, FALSE, DEBUG_WINDOW_STYLE_EX, metrics().dpi())/AdjustWindowRectEx(\&bounds, DEBUG_WINDOW_STYLE, FALSE, DEBUG_WINDOW_STYLE_EX)/g" src/osd/modules/debugger/win/disasmwininfo.cpp
sed -bi "s/AdjustWindowRectExForDpi(&bounds, DEBUG_WINDOW_STYLE, FALSE, DEBUG_WINDOW_STYLE_EX, metrics().dpi())/AdjustWindowRectEx(\&bounds, DEBUG_WINDOW_STYLE, FALSE, DEBUG_WINDOW_STYLE_EX)/g" src/osd/modules/debugger/win/logwininfo.cpp
sed -bi "s/AdjustWindowRectExForDpi(&bounds, DEBUG_WINDOW_STYLE, FALSE, DEBUG_WINDOW_STYLE_EX, metrics().dpi())/AdjustWindowRectEx(\&bounds, DEBUG_WINDOW_STYLE, FALSE, DEBUG_WINDOW_STYLE_EX)/g" src/osd/modules/debugger/win/memorywininfo.cpp
sed -bi "s/AdjustWindowRectExForDpi(&bounds, DEBUG_WINDOW_STYLE, FALSE, DEBUG_WINDOW_STYLE_EX, metrics().dpi())/AdjustWindowRectEx(\&bounds, DEBUG_WINDOW_STYLE, FALSE, DEBUG_WINDOW_STYLE_EX)/g" src/osd/modules/debugger/win/pointswininfo.cpp
sed -bi "s/GetSystemMetricsForDpi(SM_C\(..\)SCROLL, dpi)/GetSystemMetrics(SM_C\1SCROLL)/g" src/osd/modules/debugger/win/uimetrics.cpp

# 'GetLogicalProcessorInformation' missing in kernel32.dll (Windows XP)
sed -bi "s/\tDWORD resultsize/\tSYSTEM_INFO sysInfo; GetSystemInfo(\&sysInfo);\n\tunsigned default_cache_line_size = 64;\n\treturn std::make_pair(std::errc::operation_not_permitted, default_cache_line_size);\n\n\tDWORD resultsize/g" src/osd/modules/lib/osdlib_win32.cpp

# 'CancelIoEx' missing in kernel32.dll (Windows XP)
sed -bi "s/_WIN32_WINNT >= 0x0600/_WIN32_WINNT >= 0x2000/g" 3rdparty/asio/include/asio/detail/win_iocp_handle_service.hpp
sed -bi "s/_WIN32_WINNT >= 0x0600/_WIN32_WINNT >= 0x2000/g" 3rdparty/asio/include/asio/detail/win_iocp_socket_service_base.hpp
sed -bi "s/_WIN32_WINNT >= 0x0600/_WIN32_WINNT >= 0x2000/g" 3rdparty/asio/include/asio/detail/impl/win_iocp_socket_service_base.ipp

# 'CreateSymbolicLinkA' missing in kernel32.dll (Windows XP)
sed -bi "s/int result = symbolic \x3f CreateSymbolicLink(newpath, oldpath, is_dir)/int result = 0; if (symbolic) {lua_pushnil(L); lua_pushstring(L, \"Symbolic links are not supported on Windows XP.\"); return 2;} else {if (CreateHardLink(newpath, oldpath, NULL) != 0) {result = 1;}}/g;/      : CreateHardLink(newpath, oldpath, NULL);/d" 3rdparty/luafilesystem/src/lfs.c
sed -bi "s/GetFinalPathNameByHandle(h, target, size, FILE_NAME_OPENED)/GetFullPathName(file, size, target, NULL)/g" 3rdparty/luafilesystem/src/lfs.c

# 'strcat_s' missing inmsvcrt.dll
sed -bi "s/strcat_s(pm_hosterror_text, PM_HOST_ERROR_MSG_LEN/strcat(pm_hosterror_text/g" 3rdparty/portmidi/pm_win/pmwinmm.c

# 'GetPointerInfo' missing in user32.dll (Windows XP)
sed -bi "s/if (!GetPointerInfo/\/\/if (!GetPointerInfo/g" src/osd/windows/window.cpp

# 'EnableMouseInPointer' missing in user32.dll (Windows XP)
sed -bi "s/EnableMouseInPointer(FALSE)/\/\/EnableMouseInPointer(FALSE)/g" src/osd/windows/winmain.cpp

# Creating WbemLocator failed + XInput device detection failed (Windows XP)
sed -bi "s/osd_printf_error(\"Creating Wbem/\/\/osd_printf_error(\"Creating Wbem/g" src/osd/modules/input/input_winhybrid.cpp
sed -bi "s/osd_printf_warning(\"XInput/\/\/osd_printf_warning(\"XInput/g" src/osd/modules/input/input_winhybrid.cpp

# Re-added DirectSound
wget --no-check-certificate https://raw.githubusercontent.com/Robbbert/mameui/refs/heads/master/src/osd/modules/sound/direct_sound.cpp -O direct_sound.cpp
mv direct_sound.cpp src/osd/modules/sound
sed -bi "s/coreaudio_sound.cpp\",/coreaudio_sound.cpp\",\n\t\tMAME_DIR .. \"src\/osd\/modules\/sound\/direct_sound.cpp\",/g" scripts/src/osd/modules.lua
sed -bi "s/SOUND_XAUDIO2);/SOUND_XAUDIO2);\n\tREGISTER_MODULE(m_mod_man, SOUND_DSOUND);/g" src/osd/modules/lib/osdobj_common.cpp


cd /tmp
echo " "
echo " "
echo " "
echo -e "\e[33mAuto-generate arcade.flt and mess.flt files for MAME...\e[0m"
echo " "
7z x XPackage.zip
cp -f ../mingw32/lib/libkernel32.a ../mingw32/lib/libkernel32.a-bak
cp -f ../mingw32/include/psapi.h ../mingw32/include/psapi.h-bak
cp -f libkernel32.a ../mingw32/lib/libkernel32.a
cp -f psapi.h ../mingw32/include/psapi.h

echo "Patch cc1plus.exe to use the larger address space (>2GB)"
export VER="$(gcc -dumpversion)"
cp -f ../mingw32/lib/gcc/i686-w64-mingw32/$VER/cc1plus.exe ../mingw32/lib/gcc/i686-w64-mingw32/$VER/cc1plus.bak
cmd //c "editbin /LARGEADDRESSAWARE ../mingw32/lib/gcc/i686-w64-mingw32/$VER/cc1plus.exe"
cmd //c arcade+mess-flt.bat

echo " "
echo " "
echo " "
echo -e "\e[33mYou can go offline!... >>>>>>  Restart mingw32.exe launcher !!!\e[0m"
echo " "
echo " "
rm libkernel32.a psapi.h mame.zip XPackage.zip EDITBIN.EXE LINK.EXE MSPDB60.DLL init-XP32.sh
