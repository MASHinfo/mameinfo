@ECHO OFF
CLS
set path=d:\msys32\mingw32\bin;d:\msys32\usr\bin
set MINGW32=d:/msys32/mingw32

d:
cd \msys32\src\mame-master
make -j5 SUBTARGET=arcade

REM
REM Compile only one driver
REM
REM make -j5 SUBTARGET=tinymame SOURCES=src/mame/namco/rallyx.cpp REGENIE=1

IF ERRORLEVEL 2 GOTO ERROR

ECHO.
ECHO READY!
REM
REM COPY /Y D:\msys32\mamearcade.exe D:\MAME\mame.exe >NUL
REM
GOTO END
:ERROR
ECHO.
ECHO ERROR!
:END
PAUSE > NUL
