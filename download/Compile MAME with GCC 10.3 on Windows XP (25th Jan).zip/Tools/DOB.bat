@ECHO OFF
REM WORKING DIRECTORY
set DIR=D:\msys32\src\mame-master\build



COLOR 1E
ECHO.
ECHO Delete specific object files...
ECHO.
IF NOT EXIST %DIR%\projects\windows GOTO NEXT
RD /Q /S %DIR%\projects\windows
:NEXT
IF NOT EXIST %DIR%\projects\winui GOTO START
RD /Q /S %DIR%\projects\winui

:START
ECHO.
ECHO.
set /p "Text= Text >"
ECHO.
ECHO MAME
for /f "eol=: delims=" %%F in ('findstr /S /M /I "%Text%" %DIR%\*') do ECHO DEL "%%F"  &&  del "%%F"
DEL /S %DIR%\%Text%.*

GOTO START

