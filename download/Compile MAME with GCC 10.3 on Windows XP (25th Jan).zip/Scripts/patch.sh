cd /src


echo " "
echo " "
echo " "
echo " "
echo -e "\e[33mDownload newest DirectSound source file...\e[0m"
echo " "
echo " "
wget --progress=bar:force --no-check-certificate -cO - https://raw.githubusercontent.com/Robbbert/mameui/refs/heads/master/src/osd/modules/sound/direct_sound.cpp > direct_sound.cpp
echo " "
echo " "
echo -e "\e[33mPatch new MAME source!\e[0m"
cd /src/mame-master

# Patch new MAME source
sed -bi "s/# SSE2 = 1/SSE2 = 1/g" makefile
sed -bi "s/-v PROCESSOR_ARCHITECTURE/\/v PROCESSOR_ARCHITECTURE/g" makefile
sed -bi "s/b\x22\x25b\([\]\)x04\x25b\x22 \x25 \x28ctxt\x2c id\x29/id/g" scripts/build/msgfmt.py
sed -bi "s/#include <tchar.h>/#include <tchar.h>\n\n#define RI_MOUSE_HWHEEL 0x0800/g" src/osd/modules/input/input_rawinput.cpp
sed -bi "s/std\x3a\x3asetlocale\x28LC_ALL, \x22\x22\x29\x3b/\/\/std::setlocale(LC_ALL, \"\");/g" src/osd/windows/winmain.cpp

# 'TaskDialog' missing in comctl32.dll (Windows XP)
sed -bi "s/\x09\x09\x09if \x28SUCCEEDED\x28SHCreateItem/\x2f\x2f\x09\x09\x09if (SUCCEEDED(SHCreateItem/g" src/osd/modules/debugger/win/consolewininfo.cpp
sed -bi "s/\t\tint pressed;/#ifdef UNUSED_FUNCTION\n\t\tint pressed;/g" src/osd/modules/debugger/win/consolewininfo.cpp
sed -bi "s/\t\t\t\t&pressed);/\t\t\t\t\&pressed);\n#endif/g" src/osd/modules/debugger/win/consolewininfo.cpp

# 'GetLogicalProcessorInformation' missing in kernel32.dll (Windows XP)
sed -bi "s/\tDWORD resultsize/\tSYSTEM_INFO sysInfo; GetSystemInfo(\&sysInfo);\n\tunsigned default_cache_line_size = 64;\n\treturn std::make_pair(std::errc::operation_not_permitted, default_cache_line_size);\n\n\tDWORD resultsize/g" src/osd/modules/lib/osdlib_win32.cpp

# 'CancelIoEx' missing in kernel32.dll (Windows XP)
sed -bi "s/_WIN32_WINNT >= 0x0600/_WIN32_WINNT >= 0x2000/g" 3rdparty/asio/include/asio/detail/win_iocp_handle_service.hpp
sed -bi "s/_WIN32_WINNT >= 0x0600/_WIN32_WINNT >= 0x2000/g" 3rdparty/asio/include/asio/detail/win_iocp_socket_service_base.hpp
sed -bi "s/_WIN32_WINNT >= 0x0600/_WIN32_WINNT >= 0x2000/g" 3rdparty/asio/include/asio/detail/impl/win_iocp_socket_service_base.ipp

# 'CreateSymbolicLinkA' missing in kernel32.dll (Windows XP)
sed -bi "s/int result = symbolic \x3f CreateSymbolicLink(newpath, oldpath, is_dir)/int result = 0; if (symbolic) {lua_pushnil(L); lua_pushstring(L, \"Symbolic links are not supported on Windows XP.\"); return 2;} else {if (CreateHardLink(newpath, oldpath, NULL) != 0) {result = 1;}}/g;/      : CreateHardLink(newpath, oldpath, NULL);/d" 3rdparty/luafilesystem/src/lfs.c
sed -bi "s/GetFinalPathNameByHandle(h, target, size, FILE_NAME_OPENED)/GetFullPathName(file, size, target, NULL)/g" 3rdparty/luafilesystem/src/lfs.c

# Creating WbemLocator failed + XInput device detection failed (Windows XP)
sed -bi "s/osd_printf_error(\"Creating Wbem/\/\/osd_printf_error(\"Creating Wbem/g" src/osd/modules/input/input_winhybrid.cpp
sed -bi "s/osd_printf_warning(\"XInput/\/\/osd_printf_warning(\"XInput/g" src/osd/modules/input/input_winhybrid.cpp

# Re-added DirectSound
sed -bi "s/coreaudio_sound.cpp\",/coreaudio_sound.cpp\",\n\t\tMAME_DIR .. \"src\/osd\/modules\/sound\/direct_sound.cpp\",/g" scripts/src/osd/modules.lua
sed -bi "s/SOUND_XAUDIO2);/SOUND_XAUDIO2);\n\tREGISTER_MODULE(m_mod_man, SOUND_DSOUND);/g" src/osd/modules/lib/osdobj_common.cpp
mv ../direct_sound.cpp src/osd/modules/sound


cd /src
echo " "
echo " "
echo " "
echo -e "\e[33mAuto-generate arcade.flt and mess.flt files...\e[0m"
echo " "
cmd //c arcade+mess-flt.bat

echo " "
echo " "
echo " "
echo -e "\e[33mYou can go offline... Restart Windows Console.bat !!!\e[0m"
echo " "
echo " "
