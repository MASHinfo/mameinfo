@ECHO OFF
CD mame-master\src\mame

REM
REM Generate arcade.flt
REM
ECHO >>tmp.txt
DEL /F /Q tmp.txt tmp1.txt arcade.flt > NUL

findstr /S /M "GAME(" * *.cpp >>tmp.txt
findstr /S /M "GAMEL" * *.cpp >>tmp.txt
sed "s/[\]/\x2f/g" tmp.txt > tmp1.txt

REM Remove unnesessary drivers
SED "/atari\/a2600.cpp/d;/sega\/dccons.cpp/d;/skeleton\/design.cpp/d;/virtual\/ldplayer.cpp/d;/nintendo\/vt1682.cpp/d" tmp1.txt > tmp.txt

REM Add missing drivers
sed "1s/^/astrocorp\/hummer.cpp\nmerit\/mtouchxl.cpp\ncave\/cv1k_v_blit*.cpp\n/" tmp.txt > tmp1.txt

REM Sort list and remove double lines
SORT tmp1.txt >tmp.txt
sed "$!N; /^\(.*\)\n\1$/!P; D" tmp.txt > tmp1.txt

REM Merge arcade.flt with Arcade Exceptions list
COPY /B tmp1.txt + ..\..\..\exceptions(arcade).txt arcade.flt



REM
REM Generate mess.flt
REM
ECHO >>tmp.txt
DEL /F /Q tmp.txt tmp1.txt mess.flt > NUL

findstr /S /M /B "COMP" * *.cpp >>tmp.txt
findstr /S /M /B "CONS(" * *.cpp >>tmp.txt
findstr /S /M /B "SYST(" * *.cpp >>tmp.txt
sed "s/[\]/\x2f/g" tmp.txt > tmp1.txt

REM Remove unnesessary drivers
sed "/atari\/jaguar.cpp/d;/capcom\/cps1.cpp/d;/gameplan\/enigma2.cpp/d;/igs\/funtech.cpp/d;/merit\/mtouchxl.cpp/d;/neogeo\/neogeo.cpp/d;/philips\/cdi.cpp/d;/sega\/megatech.cpp/d" tmp1.txt > tmp.txt

REM Add missing drivers
sed "1s/^/skeleton\/design.cpp\nvirtual\/ldplayer.cpp\n/" tmp.txt > tmp1.txt

REM Sort list and remove double lines
SORT tmp1.txt >tmp.txt
sed "$!N; /^\(.*\)\n\1$/!P; D" tmp.txt > tmp1.txt

REM Merge mess.flt with MESS Exceptions list
COPY /B tmp1.txt + ..\..\..\exceptions(mess).txt mess.flt

DEL /F /Q tmp.txt tmp1.txt > NUL
CD ..\..\..\
