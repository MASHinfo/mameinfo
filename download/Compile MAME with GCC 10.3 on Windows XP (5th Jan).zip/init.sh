cd /
sed -i -e "s/cd \/src/export MINGW32=\/mingw32/g" "home/$USER/.bashrc"
sed -i -e "\$aexport MINGW_PREFIX=\/mingw32" "home/$USER/.bashrc"
sed -i -e "\$acd /src/mame-master" "home/$USER/.bashrc"

rm mingw32/etc/gdbinit init.sh
mv usr/bin/sh.exe.old usr/bin/sh.exe
cp -f win32/make.exe usr/bin

cd /src
miniunzip -x -o Update-Packages.zip

pacman -R --noconfirm mingw-w64-i686-gcc
pacman -U --noconfirm mingw-w64-i686-binutils-2.34-1-any.pkg.tar.xz mingw-w64-i686-zstd-1.5.0-1-any.pkg.tar.xz mingw-w64-i686-gcc-libs-10.3.0-5-any.pkg.tar.xz mingw-w64-i686-gcc-10.3.0-5-any.pkg.tar.xz mingw-w64-i686-headers-git-10.0.0.r54.gb4116e310-1-any.pkg.tar.xz mingw-w64-i686-crt-git-8.0.0.5815.9517d302-1-any.pkg.tar.xz mingw-w64-i686-xz-5.2.1-3-any.pkg.tar.xz mingw-w64-i686-python3-3.4.3-6-any.pkg.tar.xz unzip-6.0-2-i686.pkg.tar.xz tar-1.29-1-i686.pkg.tar.xz mingw-w64-i686-pkg-config-0.29.2-9003-any.pkg.tar.xz
tar -xf mingw-w64-i686-crt-git-5.0.0.4772.0a1b0885-1-any.pkg.tar.xz -C "../" "mingw32/i686-w64-mingw32/lib/libkernel32.a"
tar -xf mingw-w64-i686-headers-git-5.0.0.4774.3b51067b-1-any.pkg.tar.xz -C "../mingw32/include" "mingw32/i686-w64-mingw32/include/psapi.h" --strip-components=3

# Copy XP compatible libzstd.dll from https://github.com/facebook/zstd
unzip -o -j zstd-v1.5.0-win32.zip zstd-v1.5.0-win32/dll/libzstd.dll -d ../mingw32/bin/

# Copy missing MinGW xaudio2.h
cp -f xaudio2.h ../mingw32/i686-w64-mingw32/include/

# Copy wget.exe from https://eternallybored.org/misc/wget/1.19.4/32/wget.exe
cp -f wget.exe ../usr/bin/


echo " "
echo " "
echo " "
echo " "
echo -e "\e[33mDownload newest MAME source...\e[0m"
echo " "
echo " "
wget --progress=bar:force -cO - https://codeload.github.com/mamedev/mame/zip/master > mame.zip
wget --progress=bar:force -cO - https://raw.githubusercontent.com/Robbbert/mameui/refs/heads/master/src/osd/modules/sound/direct_sound.cpp > direct_sound.cpp
echo " "
echo " "
echo " "
echo " "
echo " "
echo -e "\e[33mYou can go offline... Extract MAME source in 2nd Window... Please wait!\e[0m"
start //Wait unzip mame.zip
echo " "
echo " "
echo " "
echo " "
echo -e "\e[33mPatch new MAME source!\e[0m"
cd /src/mame-master

# Patch new MAME source
sed -bi "s/# SSE2 = 1/SSE2 = 1/g" makefile
sed -bi "s/-v PROCESSOR_ARCHITECTURE/\/v PROCESSOR_ARCHITECTURE/g" makefile
sed -bi "s/b\x22\x25b\([\]\)x04\x25b\x22 \x25 \x28ctxt\x2c id\x29/id/g" scripts/build/msgfmt.py
sed -bi "s/#include <tchar.h>/#include <tchar.h>\n\n#define RI_MOUSE_HWHEEL 0x0800/g" src/osd/modules/input/input_rawinput.cpp
sed -bi "s/std\x3a\x3asetlocale\x28LC_ALL, \x22\x22\x29\x3b/\/\/std::setlocale(LC_ALL, \"\");/g" src/osd/windows/winmain.cpp

# 'TaskDialog' missing in comctl32.dll (Windows XP)
sed -bi "s/\x09\x09\x09if \x28SUCCEEDED\x28SHCreateItem/\x2f\x2f\x09\x09\x09if (SUCCEEDED(SHCreateItem/g" src/osd/modules/debugger/win/consolewininfo.cpp
sed -bi "s/\t\tint pressed;/#ifdef UNUSED_FUNCTION\n\t\tint pressed;/g" src/osd/modules/debugger/win/consolewininfo.cpp
sed -bi "s/\t\t\t\t&pressed);/\t\t\t\t\&pressed);\n#endif/g" src/osd/modules/debugger/win/consolewininfo.cpp

# 'GetLogicalProcessorInformation' missing in kernel32.dll (Windows XP)
sed -bi "s/\tDWORD resultsize/\tSYSTEM_INFO sysInfo; GetSystemInfo(\&sysInfo);\n\tunsigned default_cache_line_size = 64;\n\treturn std::make_pair(std::errc::operation_not_permitted, default_cache_line_size);\n\n\tDWORD resultsize/g" src/osd/modules/lib/osdlib_win32.cpp

# 'CancelIoEx' missing in kernel32.dll (Windows XP)
sed -bi "s/_WIN32_WINNT >= 0x0600/_WIN32_WINNT >= 0x2000/g" 3rdparty/asio/include/asio/detail/win_iocp_handle_service.hpp
sed -bi "s/_WIN32_WINNT >= 0x0600/_WIN32_WINNT >= 0x2000/g" 3rdparty/asio/include/asio/detail/win_iocp_socket_service_base.hpp
sed -bi "s/_WIN32_WINNT >= 0x0600/_WIN32_WINNT >= 0x2000/g" 3rdparty/asio/include/asio/detail/impl/win_iocp_socket_service_base.ipp

# 'CreateSymbolicLinkA' missing in kernel32.dll (Windows XP)
sed -bi "s/int result = symbolic \x3f CreateSymbolicLink(newpath, oldpath, is_dir)/int result = 0; if (symbolic) {lua_pushnil(L); lua_pushstring(L, \"Symbolic links are not supported on Windows XP.\"); return 2;} else {if (CreateHardLink(newpath, oldpath, NULL) != 0) {result = 1;}}/g;/      : CreateHardLink(newpath, oldpath, NULL);/d" 3rdparty/luafilesystem/src/lfs.c
sed -bi "s/GetFinalPathNameByHandle(h, target, size, FILE_NAME_OPENED)/GetFullPathName(file, size, target, NULL)/g" 3rdparty/luafilesystem/src/lfs.c

# Creating WbemLocator failed + XInput device detection failed (Windows XP)
sed -bi "s/osd_printf_error(\"Creating Wbem/\/\/osd_printf_error(\"Creating Wbem/g" src/osd/modules/input/input_winhybrid.cpp
sed -bi "s/osd_printf_warning(\"XInput/\/\/osd_printf_warning(\"XInput/g" src/osd/modules/input/input_winhybrid.cpp

# Re-added DirectSound
sed -bi "s/coreaudio_sound.cpp\",/coreaudio_sound.cpp\",\n\t\tMAME_DIR .. \"src\/osd\/modules\/sound\/direct_sound.cpp\",/g" scripts/src/osd/modules.lua
sed -bi "s/SOUND_XAUDIO2);/SOUND_XAUDIO2);\n\tREGISTER_MODULE(m_mod_man, SOUND_DSOUND);/g" src/osd/modules/lib/osdobj_common.cpp
mv ../direct_sound.cpp src/osd/modules/sound


cd /src
echo " "
echo " "
echo " "
echo -e "\e[33mAuto-generate arcade.flt and mess.flt files...\e[0m"
echo " "
cmd //c arcade+mess-flt.bat

echo " "
echo " "
echo " "
echo -e "\e[33mYou can go offline... Restart Windows Console.bat !!!\e[0m"
echo " "
echo " "
rm *tar.xz xaudio2.h wget.exe *.zip init.sh
