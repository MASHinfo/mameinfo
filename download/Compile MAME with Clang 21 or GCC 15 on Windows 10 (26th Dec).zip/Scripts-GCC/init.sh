cd /
sed -i -e "\$aexport MINGW64=/mingw64" "/home/$USER/.bashrc"
sed -i -e "\$acd /tmp/mame-master" "/home/$USER/.bashrc"

cd /tmp
echo " "
echo " "
echo " "
echo " "
echo "Download newest MAME source in 2nd Window..."
echo " "
echo " "
start wget --no-check-certificate https://codeload.github.com/mamedev/mame/zip/master -O mame.zip
echo " "
echo " "
pacman -S --noconfirm mingw-w64-x86_64-gcc
pacman -S --noconfirm mingw-w64-x86_64-python
pacman -S --noconfirm mingw-w64-x86_64-lld
pacman -S --noconfirm make
wget --no-check-certificate https://repo.mamedev.org/x86_64/mame-essentials-1.0.6-1-x86_64.pkg.tar.xz
pacman -U --noconfirm mame-essentials-1.0.6-1-x86_64.pkg.tar.xz
cd /win32
cmd //c "config64.bat"

cd /tmp
echo " "
echo " "
echo " "
echo -e "\e[33mYou can go offline... Extract MAME source in 2nd Window... Please wait!\e[0m"
start //Wait /win32/7za x mame.zip
echo " "
echo " "
cmd //c /win32/7za x XPackage.zip

cd /tmp/mame-master

# Patch new MAME source
sed -bi "s/# SSE2 = 1/SSE2 = 1/g; s/# ARCHOPTS =/ARCHOPTS = -fuse-ld=lld/g" makefile



cd /tmp
echo " "
echo " "
echo " "
echo "Auto-generate arcade.flt and mess.flt files..."
echo " "
cmd //c arcade+mess-flt.bat

echo " "
echo " "
echo " "
echo -e "\e[33mYou can go offline!... >>>>>>  Restart mingw64.exe launcher !!!\e[0m"
echo " "
echo " "
rm libkernel32.a psapi.h mame.zip XPackage.zip EDITBIN.EXE LINK.EXE MSPDB60.DLL mame-essentials-1.0.6-1-x86_64.pkg.tar.xz init.sh