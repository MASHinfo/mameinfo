cd /tmp/mame-master

# Patch new MAME source
sed -bi "s/# SSE2 = 1/SSE2 = 1/g; s/# ARCHOPTS =/ARCHOPTS = -fuse-ld=lld/g" makefile



cd /tmp
echo " "
echo " "
echo " "
echo "Auto-generate arcade.flt and mess.flt files..."
echo " "
cmd //c arcade+mess-flt.bat

cd mame-master
