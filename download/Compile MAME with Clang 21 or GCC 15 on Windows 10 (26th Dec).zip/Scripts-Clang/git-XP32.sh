cd /tmp
echo " "
echo "GIT for Windows XP MAME version..."
echo " "
echo "Remove old MAME source..."
rm -r mame-master
echo " "
echo " "
echo -e "\e[33mDownload newest MAME source...\e[0m"
echo " "
echo " "
wget --no-check-certificate https://codeload.github.com/mamedev/mame/zip/master -O mame.zip
start wget --no-check-certificate https://raw.githubusercontent.com/Robbbert/mameui/refs/heads/master/src/osd/modules/sound/direct_sound.cpp -O direct_sound.cpp
echo " "
echo " "
echo " "
echo " "
echo " "
echo -e "\e[33mYou can go offline... Extract MAME source in 2nd Window... Please wait!\e[0m"
start //Wait /win32/7za x mame.zip

echo " "
echo " "
echo -e "\e[33mPatch new MAME source!\e[0m"
cd /tmp/mame-master

# Patch new MAME source
sed -bi "s/# OVERRIDE_CC = cc/OVERRIDE_CC = clang/g; s/# OVERRIDE_CXX = c++/OVERRIDE_CXX = clang++/g" makefile
sed -bi "s/# SSE2 = 1/SSE2 = 1/g" makefile

# Clang ERRORs: '__thiscall__' only applies to function types (emu/emu.h) and SOCKET socket_ and HANDLE handle_ (emu/http.cpp)
sed -bi "s/MAME_ABI_CXX_MEMBER_CALL __thiscall/MAME_ABI_CXX_MEMBER_CALL/g" src/lib/util/abi.h
sed -bi "s/HANDLE handle_/\x2f\x2fHANDLE handle_/g" 3rdparty/asio/include/asio/detail/win_iocp_handle_service.hpp
sed -bi "s/iocp_op_cancellation(HANDLE/HANDLE handle_; iocp_op_cancellation(HANDLE/g" 3rdparty/asio/include/asio/detail/win_iocp_handle_service.hpp
sed -bi "s/SOCKET socket_/\x2f\x2fSOCKET socket_/g" 3rdparty/asio/include/asio/detail/win_iocp_socket_service_base.hpp
sed -bi "s/\([a-z]*\)_op_cancellation(SOCKET/SOCKET socket_; \1_op_cancellation(SOCKET/g" 3rdparty/asio/include/asio/detail/win_iocp_socket_service_base.hpp

# 'TaskDialog' missing in comctl32.dll (Windows XP)
sed -bi "s/\x09\x09\x09if \x28SUCCEEDED\x28SHCreateItem/\x2f\x2f\x09\x09\x09if (SUCCEEDED(SHCreateItem/g" src/osd/modules/debugger/win/consolewininfo.cpp
sed -bi "s/\t\tint pressed;/#ifdef UNUSED_FUNCTION\n\t\tint pressed;/g" src/osd/modules/debugger/win/consolewininfo.cpp
sed -bi "s/\t\t\t\t&pressed);/\t\t\t\t\&pressed);\n#endif/g" src/osd/modules/debugger/win/consolewininfo.cpp

# 'GetLogicalProcessorInformation' missing in kernel32.dll (Windows XP)
sed -bi "s/\tDWORD resultsize/\tSYSTEM_INFO sysInfo; GetSystemInfo(\&sysInfo);\n\tunsigned default_cache_line_size = 64;\n\treturn std::make_pair(std::errc::operation_not_permitted, default_cache_line_size);\n\n\tDWORD resultsize/g" src/osd/modules/lib/osdlib_win32.cpp

# 'CancelIoEx' missing in kernel32.dll (Windows XP)
sed -bi "s/_WIN32_WINNT >= 0x0600/_WIN32_WINNT >= 0x2000/g" 3rdparty/asio/include/asio/detail/win_iocp_handle_service.hpp
sed -bi "s/_WIN32_WINNT >= 0x0600/_WIN32_WINNT >= 0x2000/g" 3rdparty/asio/include/asio/detail/win_iocp_socket_service_base.hpp
sed -bi "s/_WIN32_WINNT >= 0x0600/_WIN32_WINNT >= 0x2000/g" 3rdparty/asio/include/asio/detail/impl/win_iocp_socket_service_base.ipp

# 'CreateSymbolicLinkA' missing in kernel32.dll (Windows XP)
sed -bi "s/int result = symbolic \x3f CreateSymbolicLink(newpath, oldpath, is_dir)/int result = 0; if (symbolic) {lua_pushnil(L); lua_pushstring(L, \"Symbolic links are not supported on Windows XP.\"); return 2;} else {if (CreateHardLink(newpath, oldpath, NULL) != 0) {result = 1;}}/g;/      : CreateHardLink(newpath, oldpath, NULL);/d" 3rdparty/luafilesystem/src/lfs.c
sed -bi "s/GetFinalPathNameByHandle(h, target, size, FILE_NAME_OPENED)/GetFullPathName(file, size, target, NULL)/g" 3rdparty/luafilesystem/src/lfs.c

# Creating WbemLocator failed + XInput device detection failed (Windows XP)
sed -bi "s/osd_printf_error(\"Creating Wbem/\/\/osd_printf_error(\"Creating Wbem/g" src/osd/modules/input/input_winhybrid.cpp
sed -bi "s/osd_printf_warning(\"XInput/\/\/osd_printf_warning(\"XInput/g" src/osd/modules/input/input_winhybrid.cpp

# Re-added DirectSound
sed -bi "s/coreaudio_sound.cpp\",/coreaudio_sound.cpp\",\n\t\tMAME_DIR .. \"src\/osd\/modules\/sound\/direct_sound.cpp\",/g" scripts/src/osd/modules.lua
sed -bi "s/SOUND_XAUDIO2);/SOUND_XAUDIO2);\n\tREGISTER_MODULE(m_mod_man, SOUND_DSOUND);/g" src/osd/modules/lib/osdobj_common.cpp
mv ../direct_sound.cpp src/osd/modules/sound


cd /tmp
echo " "
echo " "
echo " "
echo -e "\e[33mAuto-generate arcade.flt and mess.flt files...\e[0m"
echo " "
cmd //c arcade+mess-flt.bat

rm mame.zip
cd mame-master
