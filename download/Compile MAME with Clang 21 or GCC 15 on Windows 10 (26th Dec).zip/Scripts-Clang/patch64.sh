cd /tmp/mame-master

# Patch new MAME source
sed -bi "s/# OVERRIDE_CC = cc/OVERRIDE_CC = clang/g; s/# OVERRIDE_CXX = c++/OVERRIDE_CXX = clang++/g" makefile
sed -bi "s/# SSE2 = 1/SSE2 = 1/g; s/# ARCHOPTS =/ARCHOPTS = -fuse-ld=lld/g" makefile



cd /tmp
echo " "
echo " "
echo " "
echo "Auto-generate arcade.flt and mess.flt files..."
echo " "
cmd //c arcade+mess-flt.bat

cd mame-master
