cd /tmp
echo " "
echo "GIT for Windows 10 (64bit) MAME version..."
echo " "
echo "Remove old MAME source..."
rm -r mame-master
echo " "
echo " "
echo "Download newest MAME source..."
echo " "
echo " "
wget --no-check-certificate https://codeload.github.com/mamedev/mame/zip/master -O mame.zip
echo " "
echo " "
echo "You can go offline!"
echo " "
echo "Extract new MAME source in 2nd Window... Please wait!"
start //Wait /win32/7za x mame.zip

cd /tmp/mame-master

# Patch new MAME source
sed -bi "s/# OVERRIDE_CC = cc/OVERRIDE_CC = clang/g; s/# OVERRIDE_CXX = c++/OVERRIDE_CXX = clang++/g" makefile
sed -bi "s/# SSE2 = 1/SSE2 = 1/g; s/# ARCHOPTS =/ARCHOPTS = -fuse-ld=lld/g" makefile



cd /tmp
echo " "
echo " "
echo " "
echo "Auto-generate arcade.flt and mess.flt files..."
echo " "
cmd //c arcade+mess-flt.bat

rm mame.zip
cd mame-master
